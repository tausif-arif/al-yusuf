"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { HighlightsGrid } from "@/components/sections/highlights-grid";
import { Plane, MapPin, IndianRupee, Calendar, Utensils, Phone, Star } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);



export function Contact() {
  const sectionRef = useRef<HTMLElement>(null);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const lines = sectionRef.current?.querySelectorAll<HTMLElement>(".reveal-line");
      lines?.forEach((line) => {
        const span = line.querySelector<HTMLElement>("span");
        if (!span) return;
        gsap.fromTo(
          span,
          { y: "110%", opacity: 0 },
          {
            y: "0%",
            opacity: 1,
            duration: 1.1,
            ease: "expo.out",
            scrollTrigger: { trigger: line, start: "top 88%" },
          }
        );
      });

      gsap.fromTo(
        ".contact-body",
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 1,
          ease: "expo.out",
          scrollTrigger: { trigger: ".contact-body", start: "top 80%" },
        }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  return (
    <footer
      id="contact"
      ref={sectionRef}
      className="bg-[var(--background)] flex flex-col"
    >
      {/* Contact section */}
      <section className="min-h-svh flex flex-col justify-center pt-28 pb-20 px-5 md:px-10 border-b-hairline">
        {/* Section label */}
        <div className="label-mono text-[var(--muted)] mb-8">
          <span className="reveal-line">
            <span>06 — CONTACT · PATNA HEADQUARTERS</span>
          </span>
        </div>

        {/* Headline */}
        <div className="mb-14 md:mb-20 max-w-3xl">
          <h2 className="display-lg font-semibold leading-[0.95] tracking-tight">
            <span className="reveal-line block">
              <span>Start your journey.</span>
            </span>
            <span className="reveal-line block">
              <span className="font-light italic text-[var(--muted)]">
                Speak directly with us.
              </span>
            </span>
          </h2>
          <p className="mt-8 text-base md:text-lg text-[var(--muted)] font-light leading-relaxed max-w-xl">
            Visit our Patna office or call our team directly to reserve your seat
            for the upcoming 2026 departures. Seats fill fast.
          </p>
        </div>

        <div className="border-t-hairline mb-0" />

        {/* Contact grid — 2 cols */}
        <div
          className="contact-body grid md:grid-cols-2 bg-[var(--border)]"
          style={{ gap: "1px" }}
        >
          {/* Office details */}
          <div className="bg-[var(--card)] p-8 md:p-12 flex flex-col gap-8">
            <div>
              <div className="label-mono text-[var(--muted)] mb-4">OFFICE LOCATION</div>
              <div className="font-sans font-semibold text-2xl leading-tight text-[var(--foreground)]">
                Federal Colony, Isapur
              </div>
              <div className="text-[var(--muted)] font-light mt-2">
                Phulwari Sharif, Patna, Bihar — India
              </div>
            </div>

            <div className="border-t-hairline pt-8">
              <div className="label-mono text-[var(--muted)] mb-5">DIRECT PHONE LINES</div>
              <div className="flex flex-col gap-3">
                <a
                  href="tel:8210040715"
                  className="font-mono text-2xl font-medium text-[var(--foreground)]
                             border-b-hairline pb-3
                             transition-colors hover:text-[var(--accent)]"
                >
                  +91 82100 40715
                </a>
                <a
                  href="tel:9534562650"
                  className="font-mono text-2xl font-medium text-[var(--foreground)]
                             transition-colors hover:text-[var(--accent)]"
                >
                  +91 95345 62650
                </a>
              </div>
            </div>

            <div className="border-t-hairline pt-6">
              <div className="flex items-center gap-3">
                <span className="section-active-dot" aria-hidden="true" />
                <span className="label-mono text-[var(--muted)]">
                  MON – SAT · 10:00 AM – 7:00 PM IST
                </span>
              </div>
            </div>
          </div>

          {/* Premium CTA (Redirects to WhatsApp) */}
          <div className="bg-[var(--background)] p-8 md:p-12 flex flex-col items-start justify-center">
            
            <h3 className="text-3xl md:text-4xl font-bold mb-6 text-[var(--foreground)] tracking-tight leading-[1.1]">
              Begin your<br />sacred journey.
            </h3>
            
            <p className="text-[var(--muted)] font-light text-lg leading-relaxed mb-12 max-w-sm">
              Step away from the worldly rush and embark on a path of spiritual renewal. We meticulously handle every detail, so you can focus entirely on seeking forgiveness and peace.
            </p>

            <a
              href="https://wa.me/918210040715"
              target="_blank"
              rel="noopener noreferrer"
              className="group inline-flex items-center gap-4 border-b border-[var(--foreground)] pb-2 text-[var(--foreground)] font-mono font-medium text-sm tracking-widest uppercase transition-opacity hover:opacity-70"
            >
              RESERVE YOUR SEAT
              <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="transition-transform group-hover:translate-x-1"><path d="M8.14645 3.14645C8.34171 2.95118 8.65829 2.95118 8.85355 3.14645L12.8536 7.14645C13.0488 7.34171 13.0488 7.65829 12.8536 7.85355L8.85355 11.8536C8.65829 12.0488 8.34171 12.0488 8.14645 11.8536C7.95118 11.6583 7.95118 11.3417 8.14645 11.1464L11.2929 8H2.5C2.22386 8 2 7.77614 2 7.5C2 7.22386 2.22386 7 2.5 7H11.2929L8.14645 3.85355C7.95118 3.65829 7.95118 3.34171 8.14645 3.14645Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path></svg>
            </a>
          </div>
        </div>
      </section>



      {/* ── HIGHLIGHTS GRID ── */}
      <HighlightsGrid />

      {/* Bottom bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6
                      px-5 md:px-10 py-8 border-t-hairline">
        <div className="label-mono text-[var(--muted)]">
          © {new Date().getFullYear()} AL YUSUF HAJJ & UMRAH TOUR & TRAVELS COMPANY · PATNA
        </div>
        
        {/* Stylish Social Icons */}
        <div className="flex items-center gap-6">
          <a href="#" aria-label="Instagram" className="text-[var(--muted)] hover:text-[var(--foreground)] transition-colors duration-300">
            <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"/></svg>
          </a>
          <a href="#" aria-label="Facebook" className="text-[var(--muted)] hover:text-[var(--foreground)] transition-colors duration-300">
            <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>
          </a>
          <a href="#" aria-label="Twitter" className="text-[var(--muted)] hover:text-[var(--foreground)] transition-colors duration-300">
            <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg>
          </a>
          <a href="#" aria-label="YouTube" className="text-[var(--muted)] hover:text-[var(--foreground)] transition-colors duration-300">
            <svg className="w-[18px] h-[18px]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29 29 0 0 0 1 11.75a29 29 0 0 0 .46 5.33 2.78 2.78 0 0 0 1.94 2c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29 29 0 0 0 .46-5.33 29 29 0 0 0-.46-5.33z"/><polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02"/></svg>
          </a>
        </div>
      </div>
    </footer>
  );
}
